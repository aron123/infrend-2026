import "reflect-metadata";
import express from "express";
import { AppDataSource } from "./data-source";
import { User } from "./entity/User";

async function main() {
    await AppDataSource.initialize();

    const user = new User();
    user.name = 'Kovács Géza';

    const repository = AppDataSource.getRepository(User);
    await repository.save(user);

    console.log('Database: OK');

    const app = express();
    app.listen(3000, (err) => {
        if (err) {
            console.error(err);
            return;
        }

        console.log('Server: OK');
    });
}

main().catch(err => console.error(err));
